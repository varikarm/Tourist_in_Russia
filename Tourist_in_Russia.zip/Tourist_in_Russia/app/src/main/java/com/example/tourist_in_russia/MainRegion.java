package com.example.tourist_in_russia;

import android.app.Activity;

public class MainRegion extends Activity {
}
