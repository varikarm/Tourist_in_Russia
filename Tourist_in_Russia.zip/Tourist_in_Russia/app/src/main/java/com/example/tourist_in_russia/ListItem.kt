package com.example.tourist_in_russia

import android.icu.text.CaseMap

data class ListItem (
    var image_id:Int,
    var titleText:String,
    var contentText:String
    )
